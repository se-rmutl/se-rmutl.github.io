# งานก่อนปรับแผน สัปดาห์ที่ 1–6

งานรายสัปดาห์ที่ทำก่อนปรับเป็นการสอน 4 ครั้งสุดท้าย วางเฉพาะงานที่ทีมเคยทำจริง **ไม่ต้องทำใหม่ และไม่ต้องแก้ย้อนหลัง**

> ส่วนนี้ไม่อยู่ในการส่ง `s34-submit` ผู้สอนจะแจ้งกำหนดและวิธีนับคะแนนภายหลัง

| สัปดาห์ | งาน | ชื่อไฟล์เดิม | วางที่ | มีหรือไม่ |
|---|---|---|---|---|
| 1 | Quality Risk Cards | `W01_<TeamName>_Quality-Risk-Cards_v1.pdf` | `w01/` | [มี / ไม่มี] |
| 2 | Project Quality Route Map | `W02_<TeamName>_Project-Quality-Route-Map_v1.pdf` | `w02/` | [มี / ไม่มี] |
| 3 | Revised Critical Requirements | `W03_<TeamName>_Revised-Critical-Requirements_v1.pdf` | `w03/` | [มี / ไม่มี] |
| 4 | SRS Review และ RTM | `W04_<TeamName>_SRS-Review-and-RTM_v1.pdf` | `w04/` | [มี / ไม่มี] |
| 5 | Requirement-to-Design Trace | `W05_<TeamName>_Requirement-to-Design-Trace_v1.pdf` | `w05/` | [มี / ไม่มี] |
| 6 | Interface and Data Flow Review | `W06_<TeamName>_Interface-and-DataFlow-Review_v1.pdf` | `w06/` | [มี / ไม่มี] |

ถ้าทีมมี repo เดิมจาก Template v1 ให้คัดลอกไฟล์จาก `WEEKS/week-0X/submission/` มาวางในโฟลเดอร์ที่ตรงกัน ไม่ต้องย้ายประวัติ commit
