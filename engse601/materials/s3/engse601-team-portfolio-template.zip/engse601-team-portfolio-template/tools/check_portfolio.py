#!/usr/bin/env python3
"""ตรวจความครบถ้วนเบื้องต้นของ portfolio ENGSE601

ตรวจโครงสร้าง ลิงก์หลักฐาน และความสอดคล้องระหว่างตารางผลกับรายงานข้อบกพร่อง
ไม่ได้ให้คะแนน และไม่ได้ตัดสินว่าเนื้อหาถูกต้อง ผู้สอนเป็นผู้ตรวจเนื้อหา

ใช้:  python3 tools/check_portfolio.py [โฟลเดอร์ของ repo]
"""
import os, re, sys

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..'))
STATUSES = {'pass': 'Pass', 'fail': 'Fail', 'blocked': 'Blocked', 'not executed': 'Not Executed'}
EVID_EXT = r'(?:txt|log|png|jpe?g|gif|webp|json|csv|pdf|html|xml|md)'
PLACEHOLDERS = ['[กรอก]', '[ ]', '[ลิงก์]']
REQUIRED = ['README.md', 'TEAM.md', 'PROJECT.md', 'AI-LOG.md', 'SUBMISSIONS.md',
            '03-test-execution/execution-report.md', '04-defects-release/release-report.md']

ok, warn, info = [], [], []

def rd(rel):
    p = os.path.join(ROOT, rel)
    return open(p, encoding='utf-8', errors='replace').read() if os.path.isfile(p) else None

def tables(md):
    """คืนรายการตาราง markdown แต่ละตารางเป็น (หัว, แถว)"""
    out, cur = [], []
    for line in md.splitlines() + ['']:
        s = line.strip()
        if s.startswith('|') and s.endswith('|'):
            cur.append([c.strip() for c in s.strip('|').split('|')])
        else:
            if len(cur) >= 2 and set(''.join(cur[1])) <= set('-: '):
                out.append((cur[0], cur[2:]))
            cur = []
    return out

def links(cell):
    found = re.findall(r'\]\(([^)\s]+)\)', cell)
    found += re.findall(r'`([^`\s]+\.' + EVID_EXT + r')`', cell, flags=re.I)
    return [f for f in found if not f.startswith(('http://', 'https://'))]

def norm_status(s):
    s = re.sub(r'[*_`]', '', s).strip().lower()
    for k, v in STATUSES.items():
        if s.startswith(k):
            return v
    return None

# 1 โครงสร้าง
for f in REQUIRED:
    (ok if rd(f) is not None else warn).append(f'{"มี" if rd(f) is not None else "ไม่พบ"} `{f}`')

# 2 ช่องที่ยังไม่ได้กรอก
for f in REQUIRED + ['01-plan/README.md', '02-test-design/README.md']:
    t = rd(f)
    if t is None:
        continue
    n = sum(t.count(ph) for ph in PLACEHOLDERS)
    if n:
        info.append(f'`{f}` ยังมีช่องว่างที่ต้องกรอก {n} ช่อง')

# 3 ตารางผลและหลักฐาน
results = {}
rep = rd('03-test-execution/execution-report.md') or ''
for head, rows in tables(rep):
    h = ' '.join(head)
    if 'สถานะ' in h and 'หลักฐาน' in h and 'ผลที่คาดหวัง' in h:
        si = next(i for i, c in enumerate(head) if 'สถานะ' in c)
        ei = next(i for i, c in enumerate(head) if 'หลักฐาน' in c)
        for r in rows:
            if len(r) <= max(si, ei) or not r[0] or r[0].startswith('['):
                continue
            tc = r[0]
            st = norm_status(r[si])
            if r[si].strip() in ('', '[ ]'):
                continue
            if st is None:
                warn.append(f'{tc}: สถานะ “{r[si]}” ไม่ใช่ Pass, Fail, Blocked หรือ Not Executed')
                continue
            results[tc] = st
            if st in ('Pass', 'Fail'):
                ls = links(r[ei])
                if not ls:
                    warn.append(f'{tc} ({st}): ไม่มีลิงก์ไปยังไฟล์หลักฐาน')
                for l in ls:
                    if not os.path.exists(os.path.normpath(os.path.join(ROOT, '03-test-execution', l))):
                        warn.append(f'{tc} ({st}): ลิงก์หลักฐาน `{l}` เปิดไม่ได้ ไม่มีไฟล์นี้ใน repo')
if results:
    c = {s: sum(1 for v in results.values() if v == s) for s in STATUSES.values()}
    ok.append('ตารางผล ' + ' · '.join(f'{k} {v}' for k, v in c.items()))
else:
    info.append('ยังไม่มีแถวในตารางผล B1 ขั้นที่ 5')

tdir = os.path.join(ROOT, '03-test-execution', 'tests')
codes = [f for f in (os.listdir(tdir) if os.path.isdir(tdir) else []) if f not in ('README.md', '.gitkeep')]
(ok if codes else info).append(f'โฟลเดอร์ tests มี {len(codes)} ไฟล์' + ('' if codes else ' (ถ้าโค้ดอยู่ใน repo โครงงาน ให้สร้าง LINKS.md)'))

# 4 ข้อบกพร่องต้องมีผล Fail รองรับ
ddir = os.path.join(ROOT, '04-defects-release', 'defects')
defs = sorted(f for f in (os.listdir(ddir) if os.path.isdir(ddir) else []) if re.match(r'DEF-\d+.*\.md$', f) and not f.startswith('DEF-00'))
for f in defs:
    t = open(os.path.join(ddir, f), encoding='utf-8', errors='replace').read()
    m = re.search(r'\|\s*พบจาก TC\s*\|([^|]*)\|', t)
    tcs = re.findall(r'[A-Z]{2,4}-\d+[A-Z]?', m.group(1)) if m else []
    if not tcs:
        warn.append(f'{f}: ไม่ระบุว่าพบจาก TC ใด')
    for tc in tcs:
        if results and results.get(tc) != 'Fail':
            warn.append(f'{f}: {tc} ไม่ได้เป็น Fail ในตารางผล ข้อบกพร่องต้องมีผล Fail รองรับ')
    for lab in ('ขั้นตอนทำซ้ำ', 'ผลที่คาดหวัง', 'ผลจริง', 'หลักฐาน'):
        if lab not in t:
            warn.append(f'{f}: ไม่มีหัวข้อ “{lab}”')
fails = [k for k, v in results.items() if v == 'Fail']
rr = rd('04-defects-release/release-report.md') or ''
if fails and not defs:
    warn.append(f'มี Fail {len(fails)} ข้อ ({", ".join(fails)}) แต่ยังไม่มีไฟล์รายงานใน 04-defects-release/defects/')
if defs:
    ok.append(f'รายงานข้อบกพร่อง {len(defs)} ไฟล์')

m = re.search(r'\*\*คำตัดสิน:\*\*\s*(Conditionally Ready|Not Ready|Ready)', rr)
if m:
    ok.append(f'คำตัดสิน: {m.group(1)}')
    if m.group(1) == 'Ready' and any(v in ('Fail', 'Blocked') for v in results.values()):
        warn.append('ตัดสิน Ready ทั้งที่ตารางผลยังมี Fail หรือ Blocked ตรวจว่าเหตุผลอ้างเกณฑ์จบได้จริง')
else:
    info.append('ยังไม่ได้เลือกคำตัดสินใน release-report.md')

# 5 ความปลอดภัย
for dp, dn, fn in os.walk(ROOT):
    if '.git' in dp.split(os.sep):
        continue
    for f in fn:
        p = os.path.join(dp, f)
        rel = os.path.relpath(p, ROOT)
        if f == '.env' or f.endswith('.pem'):
            warn.append(f'`{rel}` ไม่ควร commit ไฟล์ลับ')
        if os.path.getsize(p) > 20 * 1024 * 1024:
            warn.append(f'`{rel}` ใหญ่เกิน 20 MB ให้ใส่ลิงก์แทน')
        if f.endswith(('.md', '.txt', '.js', '.py', '.json', '.yml', '.yaml')) and rel != os.path.join('tools', 'check_portfolio.py'):
            t = open(p, encoding='utf-8', errors='replace').read()
            if re.search(r'(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*["\']?[A-Za-z0-9_\-]{8,}', t, re.I) or 'PRIVATE KEY-----' in t:
                warn.append(f'`{rel}` อาจมีรหัสผ่านหรือ key ตรวจก่อนส่ง')

lines = ['# ผลตรวจ portfolio เบื้องต้น', '', 'ตรวจเฉพาะโครงสร้างและหลักฐาน ไม่ใช่คะแนน', '']
for title, items, mark in (('ต้องแก้หรือตรวจ', warn, '⚠️'), ('ยังไม่ครบ', info, '📝'), ('เรียบร้อย', ok, '✅')):
    lines.append(f'## {mark} {title} ({len(items)})')
    lines += [f'- {x}' for x in items] or ['- ไม่มี']
    lines.append('')
report = '\n'.join(lines)
print(report)
if os.environ.get('GITHUB_STEP_SUMMARY'):
    with open(os.environ['GITHUB_STEP_SUMMARY'], 'a', encoding='utf-8') as fh:
        fh.write(report + '\n')
sys.exit(0)
