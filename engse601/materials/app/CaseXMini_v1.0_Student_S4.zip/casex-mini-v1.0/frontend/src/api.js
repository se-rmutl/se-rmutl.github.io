// เรียก API ของ backend ผ่าน proxy ของ Vite
export async function api(path, { user, method = 'GET', body } = {}) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...(user ? { 'x-user': user } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

export const STATUS_LABEL = {
  AWAITING_DECISIONS: 'Awaiting Decisions',
  ACTION_REQUIRED: 'Action Required',
  READY: 'Ready',
  SUBMITTED: 'Submitted',
  APPROVED: 'Approved',
  REJECTED: 'Rejected',
  UNAVAILABLE: 'Unavailable',
  CLARIFICATION: 'Clarification',
};
