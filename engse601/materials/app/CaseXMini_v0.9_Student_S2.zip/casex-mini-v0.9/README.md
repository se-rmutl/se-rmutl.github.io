# Case X Mini v0.9 สำหรับครั้งที่ 2

แอปสาธิตที่ตัดมาจาก Case X ใช้ประกอบการออกแบบกรณีทดสอบในครั้งที่ 2 ชุดนี้**ยังไม่มีชุดทดสอบ** ชุดทดสอบจะแจกในครั้งที่ 3

> v0.9 คือรุ่นก่อนส่งมอบ **อาจมีข้อบกพร่อง** ผลที่คาดหวังในกรณีทดสอบต้องมาจากกฎในความต้องการ ไม่ใช่จากสิ่งที่แอปทำ

## วิธีรัน

ต้องมี Node.js รุ่น 18 ขึ้นไป เปิดสองหน้าต่าง

```bash
cd backend
npm install
npm start            # API ที่ http://localhost:3001
```

```bash
cd frontend
npm install
npm run dev          # หน้าจอที่ http://localhost:5173
```

เลือกผู้ใช้ทดสอบจากเมนูด้านบน: `test_organizer_01` ผู้จัด · `test_room_owner_01` เจ้าของห้อง · `test_equipment_owner_01` เจ้าของอุปกรณ์

## กฎที่แอปนี้ต้องทำ

| กฎ | ที่มา |
|---|---|
| R-A ขอล่วงหน้าได้ 3 ถึง 30 วัน | กฎสมมติเพื่อฝึก |
| R-B หนึ่งคำขอมีทรัพยากรได้ 1 ถึง 10 รายการ | กฎสมมติเพื่อฝึก |
| FR-X-04 อุปกรณ์ต้องมีผู้รับผิดชอบก่อนส่ง | CaseX SRS v1.1 |
| BR-X-01 สถานะรวมจากรายการที่จำเป็น | CaseX SRS v1.1 |
| BR-X-02 ตัดสินได้เฉพาะรายการของตน | CaseX SRS v1.1 |
| UC-X-02 ขั้นที่ 5 ผลที่ไม่ใช่ Approve ต้องมีเหตุผล | CaseX SRS v1.1 |

## ส่วนประกอบ ตรงกับเอกสารออกแบบของ Case X

| ส่วนประกอบ | ไฟล์ |
|---|---|
| C-01 หน้าจอสร้างคำขอ | `frontend/src/pages/RequestForm.jsx` |
| C-02 หน้าจอพิจารณา | `frontend/src/pages/RequestDetail.jsx` |
| C-03 บริการคำขอ | `backend/src/services/requestService.js` |
| C-05 บริการตัดสินใจ | `backend/src/services/decisionService.js` |
| สถานะรวม BR-X-01 | `backend/src/services/readinessService.js` |
| C-10 ข้อมูล | `backend/src/repository/jsonStore.js` และ `backend/data/*.json` |

## สิ่งที่ทำให้ง่ายลงเพื่อการสาธิต
- ไม่มีระบบเข้าสู่ระบบจริง เลือกผู้ใช้ทดสอบจากเมนู หรือส่ง header `x-user` ใน API
- ใช้จำนวนวันที่ขอล่วงหน้าแทนวันที่จริง
- เก็บข้อมูลเป็นไฟล์ JSON แทนฐานข้อมูล
