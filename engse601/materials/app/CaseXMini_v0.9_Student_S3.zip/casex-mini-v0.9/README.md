# Case X Mini แอปสาธิตสำหรับ ENGSE601

แอปขนาดเล็กที่ตัดมาจาก Case X ใช้สาธิตการทดสอบในครั้งที่ 2 ถึง 4 ของรายวิชา
หน้าบ้านเป็น React ส่วนหลังบ้านเป็น Node.js และ Express เก็บข้อมูลเป็นไฟล์ JSON ไม่ต้องใช้ฐานข้อมูล

> ชุดนี้คือรุ่น **v0.9 สำหรับครั้งที่ 3** มีชุดทดสอบครบ รุ่นที่แก้ข้อบกพร่องแล้วจะแจกหลังครั้งที่ 4

## ส่วนประกอบ ตรงกับเอกสารออกแบบของ Case X

| ส่วนประกอบใน HLD | ไฟล์ในแอป | ทำอะไร |
|---|---|---|
| C-01 หน้าจอสร้างคำขอ | `frontend/src/pages/RequestForm.jsx` | กรอกคำขอกิจกรรม |
| C-02 หน้าจอพิจารณา | `frontend/src/pages/RequestDetail.jsx` | เจ้าของตัดสินรายการของตน |
| C-03 บริการคำขอ | `backend/src/services/requestService.js` | ตรวจคำขอก่อนบันทึก |
| C-05 บริการตัดสินใจ | `backend/src/services/decisionService.js` | ตรวจผลการพิจารณาก่อนบันทึก |
| สถานะรวม BR-X-01 | `backend/src/services/readinessService.js` | คำนวณสถานะรวมที่ชั้นบริการ |
| C-08 การแจ้งเตือน | `backend/src/services/notificationService.js` | ยังไม่มีบริการอีเมลจริง |
| C-10 ข้อมูล | `backend/src/repository/jsonStore.js` และ `backend/data/*.json` | อ่านเขียนไฟล์ JSON |

## กฎที่แอปทำ

| กฎ | ที่มา |
|---|---|
| R-A ขอล่วงหน้าได้ 3 ถึง 30 วัน | กฎสมมติเพื่อฝึก |
| R-B หนึ่งคำขอมีทรัพยากรได้ 1 ถึง 10 รายการ | กฎสมมติเพื่อฝึก |
| FR-X-04 อุปกรณ์ต้องมีผู้รับผิดชอบก่อนส่ง | CaseX SRS v1.1 |
| BR-X-01 สถานะรวมจากรายการที่จำเป็น | CaseX SRS v1.1 |
| BR-X-02 ตัดสินได้เฉพาะรายการของตน | CaseX SRS v1.1 |
| UC-X-02 ขั้นที่ 5 ผลที่ไม่ใช่ Approve ต้องมีเหตุผล | CaseX SRS v1.1 |
| FR-X-06 แจ้งเตือนผู้จัด | CaseX SRS v1.1 ยังส่งจริงไม่ได้ |

## สิ่งที่ทำให้ง่ายลงเพื่อการสาธิต

- ไม่มีระบบเข้าสู่ระบบจริง เลือกผู้ใช้ทดสอบจากเมนู หรือส่ง header `x-user` ใน API
- ใช้จำนวนวันที่ขอล่วงหน้าแทนวันที่จริง
- เก็บข้อมูลเป็นไฟล์ JSON แทนฐานข้อมูล

## วิธีรัน

ต้องมี Node.js รุ่น 18 ขึ้นไป เลือกโฟลเดอร์รุ่นที่ต้องการ แล้วเปิดสองหน้าต่าง

```bash
cd backend
npm install
npm start            # API ที่ http://localhost:3001
```

```bash
cd frontend
npm install
npm run dev          # หน้าจอที่ http://localhost:5173
```

ผู้ใช้ทดสอบ: `test_organizer_01` ผู้จัด · `test_room_owner_01` เจ้าของห้อง · `test_equipment_owner_01` เจ้าของอุปกรณ์

## วิธีรันการทดสอบ (ครั้งที่ 3)

```bash
cd backend
npm test             # ทั้ง Unit และ API
npm run test:unit    # เฉพาะ Unit
npm run test:api     # เฉพาะ API
```

```bash
cd frontend
npx playwright install chromium   # ครั้งแรกครั้งเดียว
npm run test:e2e                  # System test ผ่านเบราว์เซอร์ จะเปิด backend ในโหมดทดสอบให้เอง
```

## ชุดทดสอบ

| ไฟล์ | ระดับ | ทดสอบอะไร |
|---|---|---|
| `backend/tests/unit/*.test.js` | Unit | กฎใน services ด้วยค่าขอบและตารางตัดสินใจ |
| `backend/tests/api/requests.api.test.js` | API · Integration | เรียกผ่าน HTTP รวมถึงเรียกตรงโดยไม่ผ่านหน้าจอ |
| `backend/tests/api/notification.mock.test.js` | API ใช้ตัวจำลอง | ระบบสั่งแจ้งเตือนหรือไม่ โดยไม่ต้องมีบริการอีเมลจริง |
| `backend/tests/api/nfr.performance.test.js` | NFR | เวลาตอบสนอง เกณฑ์เป็นค่าสมมติ |
| `frontend/e2e/requests.spec.js` | System | ผ่านเบราว์เซอร์ตั้งแต่ต้นจนจบ |

รายการกรณีทดสอบทั้งหมดและระดับที่รัน อยู่ใน `TEST_CASES.md`

## ข้อมูลทดสอบ

การทดสอบไม่ใช้ข้อมูลใน `backend/data` การทดสอบ Unit และ API สร้างโฟลเดอร์ชั่วคราวแล้วคัดลอกข้อมูลตั้งต้นจาก `backend/tests/fixtures` ก่อนทุกกรณี ส่วน System test เรียก `POST /api/_test/reset` ซึ่งเปิดเฉพาะเมื่อ `NODE_ENV=test`
