// System test: เปิดทั้ง backend (โหมดทดสอบ) และ frontend แล้วทดสอบผ่านเบราว์เซอร์
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  workers: 1,
  use: {
    baseURL: 'http://localhost:5173',
    launchOptions: process.env.PW_CHROMIUM ? { executablePath: process.env.PW_CHROMIUM } : {},
  },
  webServer: [
    { command: 'npm --prefix ../backend run start:test', url: 'http://localhost:3001/api/users', reuseExistingServer: true },
    { command: 'npm run dev -- --strictPort', url: 'http://localhost:5173', reuseExistingServer: true },
  ],
});
