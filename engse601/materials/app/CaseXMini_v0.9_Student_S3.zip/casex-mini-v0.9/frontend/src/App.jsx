import { useEffect, useState } from 'react';
import { api } from './api.js';
import RequestForm from './pages/RequestForm.jsx';
import RequestList from './pages/RequestList.jsx';
import RequestDetail from './pages/RequestDetail.jsx';

export default function App() {
  const [users, setUsers] = useState([]);
  const [user, setUser] = useState('u-org-01');
  const [page, setPage] = useState({ name: 'list' });

  useEffect(() => { api('/users').then(r => setUsers(r.data)); }, []);

  return (
    <div className="wrap">
      <header>
        <strong>Case X Mini</strong>
        <label>ผู้ใช้ทดสอบ{' '}
          <select data-testid="user-select" value={user} onChange={e => setUser(e.target.value)}>
            {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        </label>
        <nav>
          <button onClick={() => setPage({ name: 'list' })}>คำขอทั้งหมด</button>
          <button onClick={() => setPage({ name: 'new' })}>สร้างคำขอ</button>
        </nav>
      </header>
      {page.name === 'new' && <RequestForm user={user} onDone={id => setPage({ name: 'detail', id })} />}
      {page.name === 'list' && <RequestList onOpen={id => setPage({ name: 'detail', id })} />}
      {page.name === 'detail' && <RequestDetail id={page.id} user={user} />}
    </div>
  );
}
