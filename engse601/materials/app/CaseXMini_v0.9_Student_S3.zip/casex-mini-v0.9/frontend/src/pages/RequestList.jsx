import { useEffect, useState } from 'react';
import { api, STATUS_LABEL } from '../api.js';

export default function RequestList({ onOpen }) {
  const [rows, setRows] = useState([]);
  useEffect(() => { api('/requests').then(r => setRows(r.data)); }, []);
  return (
    <div className="card">
      <h2>คำขอทั้งหมด</h2>
      {rows.length === 0 && <p>ยังไม่มีคำขอ</p>}
      <table><tbody>
        {rows.map(r => (
          <tr key={r.id}>
            <td>{r.id}</td><td>{r.title}</td>
            <td><span className="badge">{STATUS_LABEL[r.status]}</span></td>
            <td><button data-testid={`open-${r.id}`} onClick={() => onOpen(r.id)}>เปิด</button></td>
          </tr>
        ))}
      </tbody></table>
    </div>
  );
}
