// C-01 หน้าจอสร้างคำขอ
import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function RequestForm({ user, onDone }) {
  const [resources, setResources] = useState([]);
  const [title, setTitle] = useState('');
  const [daysAhead, setDaysAhead] = useState('');
  const [items, setItems] = useState([{ resourceId: 'r-room-a', required: true, responsible: '' }]);
  const [errors, setErrors] = useState([]);

  useEffect(() => { api('/resources').then(r => setResources(r.data)); }, []);

  const update = (i, patch) => setItems(items.map((it, k) => (k === i ? { ...it, ...patch } : it)));
  const typeOf = id => resources.find(r => r.id === id)?.type;

  async function submit(e) {
    e.preventDefault();
    const r = await api('/requests', { user, method: 'POST', body: { title, daysAhead: Number(daysAhead), items } });
    if (r.status === 201) onDone(r.data.id);
    else setErrors(r.data.errors || [{ message: r.data.error }]);
  }

  return (
    <form onSubmit={submit} className="card">
      <h2>สร้างคำขอกิจกรรม</h2>
      <label>ชื่อกิจกรรม <input data-testid="title" value={title} onChange={e => setTitle(e.target.value)} /></label>
      <label>ขอใช้ล่วงหน้า (วัน) <input data-testid="days" type="number" value={daysAhead} onChange={e => setDaysAhead(e.target.value)} /></label>
      <h3>ทรัพยากร</h3>
      {items.map((it, i) => (
        <div className="row" key={i}>
          <select data-testid={`resource-${i}`} value={it.resourceId} onChange={e => update(i, { resourceId: e.target.value })}>
            {resources.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
          <label><input type="checkbox" checked={it.required} onChange={e => update(i, { required: e.target.checked })} /> จำเป็น</label>
          {typeOf(it.resourceId) === 'equipment' && (
            <input placeholder="ผู้รับผิดชอบ" value={it.responsible} onChange={e => update(i, { responsible: e.target.value })} />
          )}
        </div>
      ))}
      <button type="button" onClick={() => setItems([...items, { resourceId: 'r-proj-1', required: false, responsible: '' }])}>เพิ่มทรัพยากร</button>
      {errors.length > 0 && <ul className="err" data-testid="errors">{errors.map((e, i) => <li key={i}>{e.message}</li>)}</ul>}
      <button type="submit" data-testid="submit">ส่งคำขอ</button>
    </form>
  );
}
