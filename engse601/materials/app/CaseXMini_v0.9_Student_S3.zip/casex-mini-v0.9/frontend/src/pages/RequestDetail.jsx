// C-02 หน้าจอพิจารณา: แสดงปุ่มตัดสินใจเฉพาะรายการที่ผู้ใช้เป็นเจ้าของ
// หมายเหตุ: การซ่อนปุ่มเป็นเพียงการช่วยผู้ใช้ การบังคับกฎ BR-X-02 ต้องอยู่ที่ชั้นบริการ
import { useEffect, useState } from 'react';
import { api, STATUS_LABEL } from '../api.js';

export default function RequestDetail({ id, user }) {
  const [req, setReq] = useState(null);
  const [reason, setReason] = useState({});
  const [msg, setMsg] = useState('');

  const load = () => api(`/requests/${id}`).then(r => setReq(r.data));
  useEffect(() => { load(); }, [id]);

  async function decide(itemId, decision) {
    const r = await api(`/requests/${id}/items/${itemId}/decision`, { user, method: 'POST', body: { decision, reason: reason[itemId] } });
    if (r.status === 200) { setReq(r.data); setMsg(''); } else setMsg(r.data.error);
  }

  if (!req) return <p>กำลังโหลด</p>;
  return (
    <div className="card">
      <h2>{req.id} {req.title}</h2>
      <p>สถานะรวม: <span className="badge" data-testid="overall-status">{STATUS_LABEL[req.status]}</span></p>
      {req.warnings?.length > 0 && <ul className="warn">{req.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul>}
      <table><tbody>
        {req.items.map(it => (
          <tr key={it.itemId} data-testid={`item-${it.resourceId}`}>
            <td>{it.resourceName}</td><td>{it.required ? 'จำเป็น' : 'ไม่จำเป็น'}</td>
            <td>{STATUS_LABEL[it.status]}</td>
            <td>{it.ownerId === user && (
              <>
                <input placeholder="เหตุผล" value={reason[it.itemId] || ''} onChange={e => setReason({ ...reason, [it.itemId]: e.target.value })} />
                <button data-testid="approve" onClick={() => decide(it.itemId, 'APPROVED')}>อนุมัติ</button>
                <button data-testid="reject" onClick={() => decide(it.itemId, 'REJECTED')}>ปฏิเสธ</button>
              </>
            )}</td>
          </tr>
        ))}
      </tbody></table>
      {msg && <p className="err">{msg}</p>}
    </div>
  );
}
