// Unit test ของ BR-X-01 สถานะรวม (ตารางตัดสินใจจากครั้งที่ 2)
const { computeReadiness } = require('../../src/services/readinessService');

const item = (required, status, name = 'รายการ') => ({ required, status, resourceName: name });

describe('BR-X-01 สถานะรวม', () => {
  test('TC-13 รายการจำเป็นอนุมัติครบ รายการไม่จำเป็นพร้อม -> READY ไม่มีคำเตือน', () => {
    const r = computeReadiness([item(true, 'APPROVED'), item(false, 'APPROVED')]);
    expect(r).toEqual({ status: 'READY', warnings: [] });
  });
  test('TC-14 รายการจำเป็นอนุมัติครบ รายการไม่จำเป็นไม่พร้อม -> READY พร้อมคำเตือน', () => {
    const r = computeReadiness([item(true, 'APPROVED'), item(false, 'UNAVAILABLE', 'ไมโครโฟน M1')]);
    expect(r.status).toBe('READY');
    expect(r.warnings).toHaveLength(1);
  });
  test('TC-15 รายการจำเป็นยังรอผล -> AWAITING_DECISIONS (AC-X-05)', () => {
    expect(computeReadiness([item(true, 'SUBMITTED')]).status).toBe('AWAITING_DECISIONS');
  });
  test('TC-16 รายการจำเป็นถูกปฏิเสธ -> ACTION_REQUIRED (AC-X-06)', () => {
    expect(computeReadiness([item(true, 'REJECTED'), item(true, 'APPROVED')]).status).toBe('ACTION_REQUIRED');
  });
});
