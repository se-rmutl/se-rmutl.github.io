// Unit test ของ C-05 decisionService (BR-X-02 และ UC-X-02 ขั้นที่ 5)
const { checkDecision } = require('../../src/services/decisionService');

const roomOwner = { id: 'u-room-01' };
const equipOwner = { id: 'u-equip-01' };
const roomItem = { ownerId: 'u-room-01' };

describe('BR-X-02 และ UC-X-02 ขั้นที่ 5', () => {
  test('TC-17 เจ้าของอนุมัติรายการของตน -> ผ่าน', () => {
    expect(checkDecision({ user: roomOwner, item: roomItem, decision: 'APPROVED' }).ok).toBe(true);
  });
  test('TC-18 ผู้ที่ไม่ใช่เจ้าของพยายามตัดสิน -> ปฏิเสธ 403', () => {
    const r = checkDecision({ user: equipOwner, item: roomItem, decision: 'APPROVED' });
    expect(r.ok).toBe(false);
    expect(r.code).toBe(403);
  });
  test('TC-19 เจ้าของปฏิเสธโดยไม่ระบุเหตุผล -> ไม่ผ่าน 400', () => {
    const r = checkDecision({ user: roomOwner, item: roomItem, decision: 'REJECTED' });
    expect(r.code).toBe(400);
  });
  test('TC-20 เจ้าของปฏิเสธพร้อมเหตุผล -> ผ่าน', () => {
    expect(checkDecision({ user: roomOwner, item: roomItem, decision: 'REJECTED', reason: 'ห้องปิดปรับปรุง' }).ok).toBe(true);
  });
});
