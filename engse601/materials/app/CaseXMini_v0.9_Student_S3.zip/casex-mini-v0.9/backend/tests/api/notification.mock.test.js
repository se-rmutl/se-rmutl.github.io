// ตัวจำลอง (test double): แทนบริการอีเมลด้วย jest.mock
// ระดับ API ทดสอบได้ว่า "ระบบสั่งแจ้งเตือนผู้จัด" แม้ไม่มีบริการอีเมลจริง
// ส่วนการทดสอบว่า "ผู้จัดได้รับอีเมลจริง" ยังเป็น Blocked ที่ระดับระบบ (TC-22)
jest.mock('../../src/services/notificationService', () => ({
  notify: jest.fn(() => ({ sent: true })),
}));
const { resetData, USERS } = require('../helpers/testData');
const request = require('supertest');
const app = require('../../src/app');
const { notify } = require('../../src/services/notificationService');

beforeEach(() => { resetData(); notify.mockClear(); });

test('TC-22M ระดับ API ใช้ตัวจำลอง: ส่งคำขอแล้ว ระบบสั่งแจ้งเตือนผู้จัด 1 ครั้ง', async () => {
  const res = await request(app).post('/api/requests').set('x-user', USERS.organizer)
    .send({ title: 'สัมมนา', daysAhead: 10, items: [{ resourceId: 'r-room-a', required: true }] });
  expect(res.status).toBe(201);
  expect(notify).toHaveBeenCalledTimes(1);
  expect(notify).toHaveBeenCalledWith(USERS.organizer, expect.stringContaining(res.body.id));
});

test('TC-22N ระดับ API ใช้ตัวจำลอง: คำขอถูกปฏิเสธ ต้องไม่สั่งแจ้งเตือน', async () => {
  await request(app).post('/api/requests').set('x-user', USERS.organizer)
    .send({ title: 'สัมมนา', daysAhead: 40, items: [{ resourceId: 'r-room-a', required: true }] });
  expect(notify).not.toHaveBeenCalled();
});
