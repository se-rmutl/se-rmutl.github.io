// NFR-P01 (เกณฑ์สมมติเพื่อฝึก): เมื่อมีคำขอ 200 รายการ GET /api/requests ต้องตอบภายใน 500 มิลลิวินาที
// วัดบนเครื่องทดสอบ ค่าที่ได้ขึ้นกับเครื่อง จึงต้องบันทึกสภาพแวดล้อมไว้ด้วย
const { resetData, store } = require('../helpers/testData');
const request = require('supertest');
const app = require('../../src/app');

beforeEach(() => {
  resetData();
  const many = Array.from({ length: 200 }, (_, i) => ({
    id: `REQ-${String(i + 1).padStart(3, '0')}`, title: `กิจกรรม ${i + 1}`, organizerId: 'u-org-01',
    daysAhead: 10, items: [], status: 'AWAITING_DECISIONS', warnings: [], revision: 1,
  }));
  store.write('requests', many);
});

test('NFR-P01 เมื่อมีคำขอ 200 รายการ GET /api/requests ตอบภายใน 500 มิลลิวินาที', async () => {
  const t0 = Date.now();
  const res = await request(app).get('/api/requests');
  const ms = Date.now() - t0;
  expect(res.status).toBe(200);
  expect(res.body).toHaveLength(200);
  expect(ms).toBeLessThan(500);
});
