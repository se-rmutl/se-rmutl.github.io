const app = require('./app');
const store = require('./repository/jsonStore');
const path = require('path');
const PORT = process.env.PORT || 3001;
if (process.env.NODE_ENV === 'test') store.resetFrom(path.join(__dirname, '..', 'tests', 'fixtures'));
app.listen(PORT, () => console.log(`Case X Mini API พร้อมที่ http://localhost:${PORT}`));
