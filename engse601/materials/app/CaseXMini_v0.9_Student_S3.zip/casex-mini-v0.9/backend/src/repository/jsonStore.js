// C-10 Data Store: เก็บข้อมูลเป็นไฟล์ JSON แทนฐานข้อมูล
const fs = require('fs');
const path = require('path');

function dataDir() {
  return process.env.DATA_DIR
    ? path.resolve(process.env.DATA_DIR)
    : path.join(__dirname, '..', '..', 'data');
}

function read(name) {
  const file = path.join(dataDir(), `${name}.json`);
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function write(name, rows) {
  fs.mkdirSync(dataDir(), { recursive: true });
  fs.writeFileSync(path.join(dataDir(), `${name}.json`), JSON.stringify(rows, null, 2));
}

// ใช้ตอนทดสอบ: ล้างข้อมูลแล้วใส่ข้อมูลตั้งต้นจากโฟลเดอร์ fixtures
function resetFrom(fixtureDir) {
  fs.mkdirSync(dataDir(), { recursive: true });
  for (const f of fs.readdirSync(fixtureDir)) {
    if (f.endsWith('.json')) fs.copyFileSync(path.join(fixtureDir, f), path.join(dataDir(), f));
  }
}

module.exports = { read, write, resetFrom, dataDir };
