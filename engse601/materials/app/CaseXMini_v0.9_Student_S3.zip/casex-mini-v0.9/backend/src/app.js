const express = require('express');
const cors = require('cors');
const path = require('path');
const store = require('./repository/jsonStore');
const routes = require('./routes/requests');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/api', routes);

// ใช้เฉพาะตอนทดสอบระดับระบบ: รีเซ็ตข้อมูลตั้งต้นก่อนแต่ละสถานการณ์
if (process.env.NODE_ENV === 'test') {
  app.post('/api/_test/reset', (req, res) => {
    store.resetFrom(path.join(__dirname, '..', 'tests', 'fixtures'));
    res.json({ reset: true });
  });
}

module.exports = app;
