// C-08 Notification Adapter (FR-X-06)
// สภาพแวดล้อมสาธิตยังไม่มีบริการอีเมลจริง จึงส่งไม่ได้จนกว่าจะตั้งค่า MAIL_SERVICE_URL
function notify(/* userId, message */) {
  if (!process.env.MAIL_SERVICE_URL) {
    return { sent: false, reason: 'MAIL_SERVICE_NOT_CONFIGURED' };
  }
  return { sent: true };
}
module.exports = { notify };
