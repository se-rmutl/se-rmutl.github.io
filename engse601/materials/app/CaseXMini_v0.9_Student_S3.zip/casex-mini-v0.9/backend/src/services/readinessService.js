// BR-X-01 สถานะรวมคำนวณที่ชั้นบริการ จากผลของรายการที่จำเป็น
const FAILED = ['REJECTED', 'UNAVAILABLE'];

function computeReadiness(items) {
  const required = items.filter(i => i.required);
  const optional = items.filter(i => !i.required);

  if (items.some(i => FAILED.includes(i.status))) {
    return { status: 'ACTION_REQUIRED', warnings: [] };
  }
  if (required.every(i => i.status === 'APPROVED')) {
    const warnings = optional
      .filter(i => FAILED.includes(i.status))
      .map(i => `${i.resourceName} ไม่พร้อม (รายการไม่จำเป็น)`);
    return { status: 'READY', warnings };
  }
  return { status: 'AWAITING_DECISIONS', warnings: [] };
}

module.exports = { computeReadiness };
