// C-05 Decision Service: ตรวจผลการพิจารณาของเจ้าของก่อนบันทึก
// BR-X-02 ตัดสินได้เฉพาะรายการที่ตนเป็นเจ้าของ (UC-X-02 E1 ปฏิเสธและบันทึกเหตุการณ์)
// UC-X-02 ขั้นที่ 5 ผลที่ไม่ใช่ APPROVED ต้องมีเหตุผล
const DECISIONS = ['APPROVED', 'REJECTED', 'UNAVAILABLE', 'CLARIFICATION'];

function checkDecision({ user, item, decision, reason }) {
  if (!DECISIONS.includes(decision)) {
    return { ok: false, code: 400, message: 'ผลการพิจารณาไม่ถูกต้อง' };
  }
  if (decision !== 'APPROVED' && !String(reason || '').trim()) {
    return { ok: false, code: 400, message: 'ต้องระบุเหตุผลเมื่อผลไม่ใช่ Approve' };
  }
  return { ok: true };
}

module.exports = { checkDecision, DECISIONS };
