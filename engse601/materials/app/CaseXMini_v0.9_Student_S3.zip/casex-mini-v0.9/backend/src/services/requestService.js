// C-03 Event Request Service: ตรวจคำขอก่อนบันทึก
// R-A (กฎสมมติ) ขอล่วงหน้าได้ 3 ถึง 30 วัน
// R-B (กฎสมมติ) หนึ่งคำขอมีทรัพยากรได้ 1 ถึง 10 รายการ
// FR-X-04 อุปกรณ์ต้องมีผู้รับผิดชอบก่อนส่ง (UC-X-01 E1)
const MIN_DAYS = 3;
const MAX_DAYS = 30;
const MIN_ITEMS = 1;
const MAX_ITEMS = 10;

function validateRequest(input, resources) {
  const errors = [];
  const days = Number(input.daysAhead);

  if (!Number.isInteger(days)) {
    errors.push({ field: 'daysAhead', message: 'จำนวนวันต้องเป็นจำนวนเต็ม' });
  } else if (days <= MIN_DAYS || days > MAX_DAYS) {
    const message = days > MAX_DAYS
      ? `ขอล่วงหน้าได้ไม่เกิน ${MAX_DAYS} วัน`
      : `ต้องขอล่วงหน้าอย่างน้อย ${MIN_DAYS} วัน`;
    errors.push({ field: 'daysAhead', message });
  }

  const items = Array.isArray(input.items) ? input.items : [];
  if (items.length < MIN_ITEMS) {
    errors.push({ field: 'items', message: `ต้องมีทรัพยากรอย่างน้อย ${MIN_ITEMS} รายการ` });
  } else if (items.length > MAX_ITEMS) {
    errors.push({ field: 'items', message: `มีทรัพยากรได้ไม่เกิน ${MAX_ITEMS} รายการ` });
  }

  items.forEach((item, i) => {
    const res = resources.find(r => r.id === item.resourceId);
    if (!res) {
      errors.push({ field: `items[${i}]`, message: 'ไม่พบทรัพยากรนี้' });
    } else if (res.type === 'equipment' && !String(item.responsible || '').trim()) {
      errors.push({ field: `items[${i}].responsible`, message: `${res.name} ต้องระบุผู้รับผิดชอบ` });
    }
  });

  return { ok: errors.length === 0, errors };
}

module.exports = { validateRequest, MIN_DAYS, MAX_DAYS, MIN_ITEMS, MAX_ITEMS };
