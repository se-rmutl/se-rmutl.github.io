// C-09 Identity ฉบับย่อสำหรับสาธิต: ระบุผู้ใช้ด้วย header x-user แทนการเข้าสู่ระบบจริง
const store = require('../repository/jsonStore');

module.exports = function currentUser(req, res, next) {
  const id = req.header('x-user');
  const user = store.read('users').find(u => u.id === id);
  if (!user) return res.status(401).json({ error: 'ต้องเข้าสู่ระบบก่อน' });
  req.user = user;
  next();
};
