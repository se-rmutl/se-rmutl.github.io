// API ของคำขอ (C-03) และการพิจารณารายการ (C-05)
const express = require('express');
const store = require('../repository/jsonStore');
const currentUser = require('../middleware/currentUser');
const { validateRequest } = require('../services/requestService');
const { computeReadiness } = require('../services/readinessService');
const { checkDecision } = require('../services/decisionService');
const { notify } = require('../services/notificationService');

const router = express.Router();

router.get('/resources', (req, res) => res.json(store.read('resources')));
router.get('/users', (req, res) => res.json(store.read('users')));
router.get('/requests', (req, res) => res.json(store.read('requests')));

router.get('/requests/:id', (req, res) => {
  const r = store.read('requests').find(x => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: 'ไม่พบคำขอ' });
  res.json(r);
});

// UC-X-01 ส่งคำขอกิจกรรม
router.post('/requests', currentUser, (req, res) => {
  if (req.user.role !== 'organizer') return res.status(403).json({ error: 'เฉพาะผู้จัดกิจกรรม' });
  const resources = store.read('resources');
  const v = validateRequest(req.body, resources);
  if (!v.ok) return res.status(400).json({ errors: v.errors });

  const requests = store.read('requests');
  const id = `REQ-${String(requests.length + 1).padStart(3, '0')}`;
  const items = req.body.items.map((it, i) => {
    const r = resources.find(x => x.id === it.resourceId);
    return {
      itemId: `${id}-I${i + 1}`, resourceId: r.id, resourceName: r.name, type: r.type,
      ownerId: r.ownerId, required: Boolean(it.required),
      responsible: it.responsible || '', status: 'SUBMITTED',
    };
  });
  const readiness = computeReadiness(items);
  const request = {
    id, title: String(req.body.title || ''), organizerId: req.user.id,
    daysAhead: Number(req.body.daysAhead), items, status: readiness.status,
    warnings: readiness.warnings, revision: 1,
  };
  requests.push(request);
  store.write('requests', requests);
  const notification = notify(req.user.id, `ส่งคำขอ ${id} แล้ว`);
  res.status(201).json({ ...request, notification });
});

// UC-X-02 พิจารณารายการทรัพยากร
router.post('/requests/:id/items/:itemId/decision', currentUser, (req, res) => {
  const requests = store.read('requests');
  const request = requests.find(x => x.id === req.params.id);
  if (!request) return res.status(404).json({ error: 'ไม่พบคำขอ' });
  const item = request.items.find(i => i.itemId === req.params.itemId);
  if (!item) return res.status(404).json({ error: 'ไม่พบรายการ' });

  const { decision, reason } = req.body;
  const check = checkDecision({ user: req.user, item, decision, reason });
  const audit = store.read('audit');
  if (!check.ok) {
    if (check.code === 403) {
      audit.push({ at: new Date().toISOString(), actor: req.user.id, action: 'DENIED', itemId: item.itemId });
      store.write('audit', audit);
    }
    return res.status(check.code).json({ error: check.message });
  }

  item.status = decision;
  item.reason = reason || '';
  const readiness = computeReadiness(request.items);
  request.status = readiness.status;
  request.warnings = readiness.warnings;
  request.revision += 1;
  store.write('requests', requests);
  audit.push({ at: new Date().toISOString(), actor: req.user.id, action: decision, itemId: item.itemId, reason: item.reason, revision: request.revision });
  store.write('audit', audit);
  res.json(request);
});

module.exports = router;
