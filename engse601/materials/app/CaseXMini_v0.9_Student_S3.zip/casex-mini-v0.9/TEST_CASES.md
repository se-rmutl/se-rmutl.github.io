# กรณีทดสอบเชิงตรรกะ และตำแหน่งที่รันจริง

กรณีทดสอบเชิงตรรกะมาจากครั้งที่ 2 แต่ละข้อรันได้มากกว่าหนึ่งระดับ

| TC | กฎ | ค่าหรือกรณี | ผลที่คาดหวัง | Unit | API | System |
|---|---|---|---|---|---|---|
| TC-01 | R-A | 2 วัน | ปฏิเสธ | requestService | requests.api | |
| TC-02 | R-A | 3 วัน | รับ | requestService | requests.api | |
| TC-03 | R-A | 15 วัน | รับ | requestService | | |
| TC-04 | R-A | 30 วัน | รับ | requestService | | |
| TC-05 | R-A | 31 วัน | ปฏิเสธ | requestService | | |
| TC-06 | R-B | 0 รายการ | ปฏิเสธ | requestService | | |
| TC-07 | R-B | 1 รายการ | รับ | requestService | | |
| TC-08 | R-B | 10 รายการ | รับ | requestService | | |
| TC-09 | R-B | 11 รายการ | ปฏิเสธ | requestService | | |
| TC-10 | FR-X-04 | อุปกรณ์มีผู้รับผิดชอบ | รับ | requestService | | |
| TC-11 | FR-X-04 | อุปกรณ์ไม่มีผู้รับผิดชอบ | ปฏิเสธ บอกสิ่งที่ขาด | requestService | requests.api | |
| TC-12 | FR-X-04 | ไม่มีอุปกรณ์ | รับ | requestService | | |
| TC-13 | BR-X-01 | จำเป็นครบ ไม่จำเป็นพร้อม | READY | readinessService | | |
| TC-14 | BR-X-01 | จำเป็นครบ ไม่จำเป็นไม่พร้อม | READY พร้อมคำเตือน | readinessService | | |
| TC-15 | BR-X-01 | จำเป็นรอผล | AWAITING_DECISIONS | readinessService | | |
| TC-16 | BR-X-01 | จำเป็นถูกปฏิเสธ | ACTION_REQUIRED | readinessService | | |
| TC-17 | BR-X-02 | เจ้าของอนุมัติ | บันทึกได้ | decisionService | | SYS-02 |
| TC-18 | BR-X-02 | ไม่ใช่เจ้าของ | ปฏิเสธ 403 และบันทึกเหตุการณ์ | decisionService | requests.api | SYS-03 ตรวจเฉพาะการซ่อนปุ่ม |
| TC-19 | UC-X-02 ขั้น 5 | ปฏิเสธไม่มีเหตุผล | ไม่ให้บันทึก | decisionService | | |
| TC-20 | UC-X-02 ขั้น 5 | ปฏิเสธมีเหตุผล | บันทึกได้ | decisionService | | |
| TC-21 | BR-X-01 FR-X-09 | อนุมัติรายการเดียวที่จำเป็น | READY และมีบันทึกผู้กระทำ | | requests.api | SYS-02 |
| TC-22 | FR-X-06 | ส่งคำขอแล้ว | ผู้จัดได้รับอีเมลจริง | | | Blocked ไม่มีบริการอีเมล |
| TC-22M | FR-X-06 | ส่งคำขอสำเร็จ | ระบบสั่งแจ้งเตือนผู้จัด 1 ครั้ง | | notification.mock ใช้ตัวจำลอง | |
| TC-22N | FR-X-06 | คำขอถูกปฏิเสธ | ไม่สั่งแจ้งเตือน | | notification.mock ใช้ตัวจำลอง | |
| NFR-P01 | NFR (สมมติ) | มีคำขอ 200 รายการ | GET /api/requests ตอบภายใน 500 ms | | nfr.performance | |
| TC-23 | CON-X-01 | ไม่เข้าสู่ระบบ | ปฏิเสธ 401 | | requests.api | |
| SYS-01 | AC-X-02 | ส่งคำขอผ่านหน้าจอ | เห็น Awaiting Decisions | | | SYS-01 |
