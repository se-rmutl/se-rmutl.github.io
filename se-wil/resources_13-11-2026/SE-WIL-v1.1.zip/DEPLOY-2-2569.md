# ขั้นตอน deploy SE-WIL ส่วนที่ 1–2 สำหรับภาค 2/2569

ไฟล์นี้อยู่ใน `se-wil/resources/sewil-app/` ซึ่งไม่ขึ้น git (กฎ `resources/` ใน `.gitignore` ของ repo)

## กำหนดเวลาที่ต้องทัน

| วันที่ | สิ่งที่ต้องเสร็จ | อ้างอิงพอร์ทัล |
|---|---|---|
| อา. 8 พ.ย. | deploy และทดสอบครบวงจร | |
| จ. 9 พ.ย. | ใส่รายชื่อจริง ใส่ลิงก์ระบบในพอร์ทัล ประกาศให้นักศึกษาเข้าระบบ | เริ่มช่วงเตรียมการ |
| ศ. 13 พ.ย. | นักศึกษาส่งข้อมูลที่ฝึกครบ | `PLACEMENT_DUE` |
| ส. 14 พ.ย. | อาจารย์ (บทบาท admin) อนุมัติครบ ระบบส่ง SE-WIL01 ให้สถานประกอบการทันทีที่อนุมัติ | |
| จ. 16 พ.ย. | สถานประกอบการยืนยันข้อตกลงครบ | `AGREEMENT_DUE` |
| พ. 18 พ.ย. | เปิดภาค นักศึกษาบันทึก logbook ได้ตั้งแต่วันนี้ | `SEMESTER_START` |
| ศ. 20 พ.ย. | ระบบส่งสรุป logbook ให้ผู้นิเทศงานครั้งแรก ราว 15:00–16:00 น. | |

## ตัดสินใจก่อนเริ่ม

1. **บัญชีที่ใช้ deploy คือ `dev2solution@gmail.com`** ซึ่งเป็นเจ้าของโฟลเดอร์ Drive "SE-WIL"
   - บัญชีนี้จะเป็นผู้ส่งอีเมลทุกฉบับ เป็นเจ้าของชีตฐานข้อมูล และเป็นเจ้าของไฟล์ข้อตกลง
   - สร้างชีต รัน setup และ deploy ด้วยบัญชีเดียวกันทั้งหมด อย่าสลับบัญชีกลางทาง
2. **โควตาอีเมล:** บัญชี Gmail ส่งได้ประมาณ 100 ผู้รับต่อวัน
   - ขอลิงก์เข้าระบบ 1 ฉบับต่อครั้ง อนุมัติ 1 ราย 2 ฉบับ
   - ถ้านักศึกษาเกิน 30 คน ให้ทยอยอนุมัติวันละไม่เกินประมาณ 30 ราย และดูโควตาที่เมนู SE-WIL > ตรวจโควตาอีเมลวันนี้
3. **ผู้อนุมัติ:** อาจารย์ที่ต้องกดอนุมัติต้องมีบทบาท `admin` ในชีต Users บทบาท `teacher` ดูได้อย่างเดียว
4. **ข้อ 5.3–5.4 ของแม่แบบ SE-WIL01** (ทรัพย์สินทางปัญญาและความลับ) ควรให้นิติกรหรือกรรมการบริหารหลักสูตรดูก่อนอนุมัติรายแรก

## ขั้นตอน

### 1. สร้างชีตในโฟลเดอร์ของรายวิชา (5 นาที)
1. เปิด Chrome ด้วยบัญชี `dev2solution@gmail.com`
2. เปิดโฟลเดอร์ https://drive.google.com/drive/folders/1s63FXDiSsHcWrxTzGkSnyUApR1iE27uF
3. New > Google Sheets ตั้งชื่อ `SE-WIL ฐานข้อมูล 2-2569`
4. คัดลอก ID ของชีตจาก URL (ส่วนระหว่าง `/d/` กับ `/edit`)

### 2. ใส่โค้ด

**ทาง ก: clasp (แนะนำ เพราะส่วนที่ 3–6 จะส่งโค้ดซ้ำได้ด้วยคำสั่งเดียว)**
1. เปิด Apps Script API ของบัญชี dev2solution ที่ https://script.google.com/home/usersettings
2. ในเทอร์มินัล:
   ```bash
   npm install -g @google/clasp
   clasp login                      # เลือกบัญชี dev2solution@gmail.com ในเบราว์เซอร์
   cd ~/class/se/2569/2-69/se-rmutl.github.io/se-wil/resources/sewil-app
   node test/run.js                 # ต้องได้ 143 passed, 0 failed
   mkdir -p deploy && cd deploy
   clasp create --title "SE-WIL 2-2569" --parentId "<ID ของชีต>"
   cp ../src/* .                    # ทับ appsscript.json ที่ clasp สร้าง ด้วยของระบบ
   clasp push -f
   ```
3. เปิดชีตใหม่อีกครั้ง แล้ว Extensions > Apps Script จะเห็นไฟล์ 14 ไฟล์

**ทาง ข: คัดลอกเอง (ไม่ต้องติดตั้งอะไร)**
1. ในชีต เปิด Extensions > Apps Script แล้วตั้งชื่อโปรเจกต์ `SE-WIL 2-2569`
2. Project Settings (รูปเฟือง) > ติ๊ก "Show appsscript.json manifest file in editor"
3. กลับไปที่ Editor แทนเนื้อหา `appsscript.json` ด้วยไฟล์ใน `src/`
4. ลบ `Code.gs` ที่มีมาให้ แล้วสร้างไฟล์ Script ชื่อ `Config` `Logic` `Db` `Auth` `Mail` `Placement` `Agreement` `Logbook` `Setup` `Code` และไฟล์ HTML ชื่อ `Index` `Styles` `App`
5. คัดลอกเนื้อหาจาก `src/` ไฟล์ชื่อเดียวกันมาวางทีละไฟล์ แล้วกด Save

### 3. ตั้งค่าระบบ (5 นาที)
1. รีเฟรชชีต รอเมนู **SE-WIL** แล้วกด **1) ตั้งค่าระบบ**
2. หน้าขอสิทธิ์ขึ้นคำเตือน "Google hasn't verified this app" ให้กด Advanced > Go to SE-WIL 2-2569 (unsafe) > Allow
3. ตรวจผล
   - ชีต 8 แผ่น: Config, Users, Placements, Supervisors, Logbook, CertBatches, Sessions, Audit
   - ในโฟลเดอร์ SE-WIL มีแม่แบบ "SE-WIL01 แม่แบบข้อตกลง" และโฟลเดอร์ "ข้อตกลง SE-WIL01 2-2569"
   - ชีต Users มีแถว admin ของ dev2solution
4. ชีต **Config** แก้ 1 ช่อง ตรวจ 4 ช่อง
   - `PROGRAM_EMAIL`: อีเมลที่ให้ผู้รับตอบกลับ เช่น อีเมล rmutl.ac.th ของท่าน
   - ตรวจว่า `PORTAL_URL`, `PLACEMENT_DUE`, `AGREEMENT_DUE`, `ROOT_FOLDER_ID` มีค่าแล้ว

### 4. ตรวจแม่แบบ SE-WIL01
เปิดแม่แบบในโฟลเดอร์ SE-WIL แก้ข้อความได้ แต่ต้องคง `{{...}}` ไว้ทุกช่อง

### 5. Deploy เป็นเว็บแอป (5 นาที)
1. ใน Apps Script: Deploy > New deployment > รูปเฟือง > **Web app**
2. Description: `v1.1` Execute as: **Me (dev2solution@gmail.com)** Who has access: **Anyone**
3. Deploy แล้วคัดลอก URL ที่ลงท้ายด้วย `/exec`
4. วาง URL ในชีต Config ช่อง `APP_URL`
5. จด URL และ Deployment ID ไว้ในไฟล์ `resources/data/deployment.txt`

### 6. ติดตั้งตัวจัดเวลา
เมนู SE-WIL > **2) ติดตั้งตัวจัดเวลาส่งสรุปรายสัปดาห์** ต้องขึ้นข้อความ "ส่งสรุปทุกวันศุกร์ ประมาณ 15:00 น."

### 7. ทดสอบครบวงจร (20 นาที)
logbook รับเฉพาะวันที่ตั้งแต่วันเปิดภาค จึงต้องเลื่อนวันชั่วคราวระหว่างทดสอบ

1. ชีต Config: ตั้ง `SEMESTER_START` เป็นวันนี้ `2026-11-08` ชั่วคราว
2. ชีต Users เพิ่ม 1 แถว: อีเมล rmutl.ac.th ของท่าน `role` = `student` `student_id` = `TEST-01` `active` = `TRUE`
3. เปิด URL `/exec` ใส่อีเมล rmutl.ac.th ของท่าน
   - ดูว่าอีเมลลิงก์เข้าระบบไปอยู่ Inbox หรือ Junk ของ Outlook นี่คือสิ่งที่นักศึกษาจะเจอ
4. กรอกข้อมูลที่ฝึก ใส่อีเมล Gmail อีกบัญชีของท่าน (เช่น tkeatkaew@gmail.com) เป็นผู้นิเทศงาน แล้วส่ง
5. เข้าระบบอีกครั้งด้วย dev2solution (admin) แล้วอนุมัติ
   - ไฟล์ Docs และ PDF ต้องอยู่ในโฟลเดอร์ "ข้อตกลง SE-WIL01 2-2569"
   - อีเมลถึงผู้นิเทศงานต้องมี PDF แนบ ข้อความ "กรุณายืนยันภายในวันที่ 16 พฤศจิกายน 2569" และลิงก์คู่มือผู้นิเทศงาน
6. เปิดลิงก์ผู้นิเทศงานจากอีเมล แล้วยืนยันข้อตกลง
7. กลับไปฝั่งนักศึกษา บันทึก logbook วันนี้ 2 รายการ (305 และ 304) แล้วกด "ส่งให้ผู้นิเทศงานรับรองตอนนี้"
8. เปิดลิงก์ผู้นิเทศงาน รับรอง 1 รายการ ส่งกลับ 1 รายการ แล้วดูว่าฝั่งนักศึกษาเห็นสถานะถูกต้อง
9. เคลียร์ข้อมูลทดสอบ
   - Config: คืน `SEMESTER_START` เป็น `2026-11-18`
   - ลบแถวทดสอบ (เหลือหัวคอลัมน์) ในชีต Placements, Logbook, CertBatches, Supervisors, Sessions และแถว TEST-01 ใน Users
   - ลบไฟล์ข้อตกลงทดสอบในโฟลเดอร์ข้อตกลง เลขข้อตกลงจะเริ่ม 001 ใหม่เอง
   - ชีต Audit เก็บไว้ได้

### 8. ใส่รายชื่อจริง (จ. 9 พ.ย.)
1. ชีต Users: เลือกคอลัมน์ `student_id` แล้ว Format > Number > **Plain text** ก่อนวาง
2. วางรายชื่อจาก `resources/data/` (ไฟล์ตัวอย่าง `Users_template.csv`)
   - นักศึกษา: `student`
   - อาจารย์ที่อนุมัติ: `admin`
   - อาจารย์อื่น: `teacher`
   - `advisor_email` ของนักศึกษาแต่ละคน
3. ส่ง URL `/exec` มาให้ Claude หรือแก้ `se-wil/config.js` เอง ที่ `links` รายการ `key: 'sewil'` ช่อง `url` แล้ว commit ปุ่ม "เข้าระบบ SE-WIL" ในพอร์ทัลจะกดได้
4. ประกาศนักศึกษา: เข้าระบบที่พอร์ทัล กรอกภายใน 13 พ.ย. ถ้าไม่ได้รับอีเมลให้ดู Junk

## อัปเดตโค้ดภายหลัง (ส่วนที่ 3–6 หรือแก้ไข)
```bash
cd ~/class/se/2569/2-69/se-rmutl.github.io/se-wil/resources/sewil-app
node test/run.js                       # ต้องผ่านทั้งหมดก่อนส่งขึ้น
cp src/* deploy/ && cd deploy && clasp push -f
```
จากนั้นใน Apps Script: Deploy > Manage deployments > ดินสอ > Version: **New version** > Deploy
URL `/exec` จะคงเดิม อย่ากด New deployment เพราะจะได้ URL ใหม่ และต้องแก้ `APP_URL` กับลิงก์ในพอร์ทัล
