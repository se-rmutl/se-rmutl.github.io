/* Node test harness: loads all .gs files into one vm context with in-memory mocks of
 * SpreadsheetApp, Utilities, MailApp, LockService, PropertiesService, Session, ScriptApp.
 * Run: node test/run.js
 */
'use strict';
const vm = require('vm');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const SRC = path.join(__dirname, '..', 'src');
let pass = 0, failN = 0;
function ok(cond, msg) { if (cond) { pass++; } else { failN++; console.log('  ✗ ' + msg); } }
function eq(a, b, msg) { ok(a === b, msg + ' (got ' + JSON.stringify(a) + ', want ' + JSON.stringify(b) + ')'); }

/* ---------- Sheets mock (emulates auto-conversion of typed strings) ---------- */
function conv(v) {
  if (typeof v === 'string') {
    if (v.startsWith("'")) return v.slice(1);
    if (v.startsWith('=')) return '#FORMULA!';
    if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return new Date(v + 'T00:00:00+07:00');
    if (/^\d{4}-\d{2}-\d{2}T/.test(v)) return new Date(v);
    if (/^\d{1,2}:\d{2}$/.test(v)) return new Date('1899-12-30T' + v.padStart(5, '0') + ':00+07:00');
    if (/^-?\d+(\.\d+)?$/.test(v)) return Number(v);
  }
  return v;
}
class Range {
  constructor(sh, r, c, nr, nc) { Object.assign(this, { sh, r, c, nr: nr || 1, nc: nc || 1 }); }
  getValues() {
    const out = [];
    for (let i = 0; i < this.nr; i++) {
      const row = this.sh.data[this.r - 1 + i] || [];
      const o = [];
      for (let j = 0; j < this.nc; j++) { const v = row[this.c - 1 + j]; o.push(v === undefined ? '' : v); }
      out.push(o);
    }
    return out;
  }
  setValues(vals) {
    vals.forEach((row, i) => {
      const rr = this.r - 1 + i;
      while (this.sh.data.length <= rr) this.sh.data.push([]);
      row.forEach((v, j) => { this.sh.data[rr][this.c - 1 + j] = conv(v); });
    });
    return this;
  }
  setFontWeight() { return this; }
}
class Sheet {
  constructor(name) { this.name = name; this.data = []; }
  getLastRow() { return this.data.length; }
  getLastColumn() { return this.data.reduce((m, r) => Math.max(m, r.length), 0); }
  getRange(r, c, nr, nc) { return new Range(this, r, c, nr, nc); }
  appendRow(row) { this.data.push(row.map(conv)); }
  deleteRow(r) { this.data.splice(r - 1, 1); }
  setFrozenRows() { }
}
const book = { sheets: {}, getId: () => 'SS1', getSheetByName(n) { return this.sheets[n] || null; }, insertSheet(n) { return (this.sheets[n] = new Sheet(n)); } };

/* ---------- other mocks ---------- */
const props = {};
const outbox = [];
let activeUser = 'owner@gmail.com';
function formatDate(d, tz, fmt) {
  const parts = {};
  new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
    .formatToParts(d).forEach(p => { parts[p.type] = p.value; });
  if (parts.hour === '24') parts.hour = '00';
  return fmt.replace(/'([^']*)'|yyyy|MM|dd|HH|mm|ss/g, (m, lit) => lit !== undefined ? lit :
    ({ yyyy: parts.year, MM: parts.month, dd: parts.day, HH: parts.hour, mm: parts.minute, ss: parts.second })[m]);
}
const ctx = {
  console, Date, Math, JSON, Object, Array, String, Number, Error, RegExp, Promise, encodeURIComponent, parseInt, isNaN,
  SpreadsheetApp: { openById: () => book, getActiveSpreadsheet: () => book, getUi: () => { throw new Error('no ui'); } },
  PropertiesService: { getScriptProperties: () => ({ getProperty: k => (k in props ? props[k] : null), setProperty: (k, v) => { props[k] = String(v); } }) },
  LockService: { getScriptLock: () => ({ waitLock() { }, releaseLock() { } }) },
  Utilities: {
    getUuid: () => crypto.randomUUID(),
    computeDigest: (alg, s) => Array.from(crypto.createHash('sha256').update(String(s), 'utf8').digest()).map(b => (b > 127 ? b - 256 : b)),
    DigestAlgorithm: { SHA_256: 'SHA_256' }, Charset: { UTF_8: 'UTF_8' },
    formatDate
  },
  MailApp: { sendEmail: o => outbox.push(o), getRemainingDailyQuota: () => 100 },
  Session: { getActiveUser: () => ({ getEmail: () => activeUser }), getEffectiveUser: () => ({ getEmail: () => 'owner@gmail.com' }) },
  ScriptApp: { getService: () => ({ getUrl: () => 'https://script.google.com/macros/s/TEST/exec' }) },
  DriveApp: {}, DocumentApp: {}, HtmlService: {}
};
vm.createContext(ctx);
for (const f of ['Config.gs', 'Logic.gs', 'Db.gs', 'Auth.gs', 'Mail.gs', 'Placement.gs', 'Agreement.gs', 'Logbook.gs', 'Setup.gs', 'Code.gs']) {
  vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8'), ctx, { filename: f });
}
// stub Drive/Docs-dependent functions
ctx.outputFolder_ = () => ({ getId: () => 'FOLDER' });
ctx.rootFolder_ = () => ({ getId: () => 'ROOT', getName: () => 'SE-WIL' });
ctx.templateDoc_ = () => 'TEMPLATE';
let genCalls = 0;
ctx.generateAgreement_ = (p) => { genCalls++; return { docId: 'DOC' + genCalls, pdfId: 'PDF' + genCalls, pdfUrl: 'https://drive.google.com/file/d/PDF' + genCalls, blob: { name: p.agreement_no + '.pdf' } }; };

const run = (code) => vm.runInContext(code, ctx);
const tokenFrom = (mail, key) => { const m = new RegExp(key + '=([a-zA-Z0-9]+)').exec(mail.htmlBody); return m && m[1]; };
const lastMailTo = (to) => outbox.filter(m => m.to === to).slice(-1)[0];

/* ---------- 1. pure logic ---------- */
console.log('1. Logic');
eq(run("weekIndex_('2026-11-18','2026-11-18')"), 1, 'week of opening day');
eq(run("weekIndex_('2026-11-16','2026-11-18')"), 1, 'Monday of opening week');
eq(run("weekIndex_('2026-11-22','2026-11-18')"), 1, 'Sunday of opening week');
eq(run("weekIndex_('2026-11-23','2026-11-18')"), 2, 'next Monday');
eq(run("weekIndex_('2027-03-09','2026-11-18')"), 17, 'last day (Tue) in calendar week 17');
eq(run("computeHours_('08:00','12:00',0)"), 4, '4 hours');
eq(run("computeHours_('08:30','17:00',60)"), 7.5, 'with lunch');
eq(run("computeHours_('12:00','08:00',0)"), null, 'end before start');
eq(run("computeHours_('08:00','08:30',45)"), null, 'break longer than span');
eq(run("cellOut_('2026-11-20')"), "'2026-11-20", 'date string protected');
eq(run("cellOut_('08:00')"), "'08:00", 'time string protected');
eq(run("cellOut_('=1+1')"), "'=1+1", 'formula protected');
eq(run("cellOut_('+66 81 234 5678')"), "'+66 81 234 5678", 'phone protected');
eq(run("cellOut_('ข้อความ')"), 'ข้อความ', 'Thai text unchanged');
eq(run("cellOut_(4.5)"), 4.5, 'number unchanged');
eq(run("expectedHours_('2026-11-30','2026-11-18',20,300)"), 40, 'expected after 2 weeks');
eq(run("expectedHours_('2027-06-01','2026-11-18',20,300)"), 300, 'expected capped');
const v1 = run("validateEntry_({entry_id:'',date:'2026-11-20',start:'09:00',end:'11:00',break_min:0,course:'305',work_mode:'onsite',activity:'ทดสอบงานยาวพอสมควร'},{semesterStart:'2026-11-18',semesterEnd:'2027-03-09',today:'2026-11-25',maxHoursPerDay:12,sameDay:[{entry_id:'E1',start:'08:00',end:'10:00',hours:2}]})");
ok(!v1.ok && v1.errors.join().indexOf('ซ้อน') >= 0, 'overlap detected');
eq(run("canTransition_('submitted','agreement_sent')"), true, 'transition submitted->agreement_sent');
eq(run("canTransition_('signed','returned')"), false, 'signed is final');

/* ---------- 2. security surface ---------- */
console.log('2. Public functions');
const allow = /^(doGet|onOpen|setup|installTriggers|runDigestNow|rebuildTemplate|showMailQuota|job_weeklyDigest|api_[a-zA-Z]+)$/;
fs.readdirSync(SRC).filter(f => f.endsWith('.gs')).forEach(f => {
  const src = fs.readFileSync(path.join(SRC, f), 'utf8');
  (src.match(/^function\s+([A-Za-z0-9_]+)/gm) || []).map(s => s.split(/\s+/)[1]).forEach(name => {
    if (!name.endsWith('_')) ok(allow.test(name), f + ': public function "' + name + '" not in allowlist');
  });
});

/* ---------- 3. setup ---------- */
console.log('3. Setup');
activeUser = '';
let threw = false; try { run('setup()'); } catch (e) { threw = /เจ้าของ/.test(e.message); }
ok(threw, 'setup refused for anonymous caller');
activeUser = 'owner@gmail.com';
run('setup()');
ok(book.sheets.Users && book.sheets.Logbook && book.sheets.Config, 'sheets created');
eq(run("readAll_('Users').length"), 1, 'owner seeded as admin');
// test semester: started 10 days ago
const today = run('todayStr_()');
const start = new Date(Date.parse(today + 'T00:00:00Z') - 10 * 864e5).toISOString().slice(0, 10);
const dayBefore = (n) => new Date(Date.parse(today + 'T00:00:00Z') - n * 864e5).toISOString().slice(0, 10);
run(`(function(){ var r=findOne_('Config',function(x){return x.key==='SEMESTER_START';}); update_('Config', r._row, {value:'${start}'}); resetConfigCache_(); })()`);
eq(run('cfg_().SEMESTER_START'), start, 'config updated and read back as string');
run(`insert_('Users',{email:'s1@live.rmutl.ac.th',role:'student',student_id:'66543206001',name:'นายทดสอบ ระบบ',section:'ซว4ก',advisor_email:'t1@rmutl.ac.th',active:'TRUE'})`);
run(`insert_('Users',{email:'t1@rmutl.ac.th',role:'teacher',student_id:'',name:'อ.ที่ปรึกษา',section:'',advisor_email:'',active:'TRUE'})`);
run(`insert_('Users',{email:'a1@rmutl.ac.th',role:'admin',student_id:'',name:'หัวหน้าหลักสูตร',section:'',advisor_email:'',active:'TRUE'})`);
eq(run("findUser_('S1@LIVE.rmutl.ac.th').student_id"), '66543206001', 'student id stays text (no number conversion)');

/* ---------- 4. login ---------- */
console.log('4. Login');
function login(email) {
  const r = run(`api_requestLogin(${JSON.stringify(email)})`);
  ok(r.ok, 'requestLogin ok for ' + email);
  const t = tokenFrom(lastMailTo(email.trim().toLowerCase()), 't');
  ok(!!t, 'login mail has token');
  const x = run(`api_exchange('${t}')`);
  ok(x.ok, 'exchange ok');
  return { s: x.session, t };
}
const n0 = outbox.length;
eq(run("api_requestLogin('nobody@example.com').ok"), true, 'unknown email returns ok');
eq(outbox.length, n0, 'no mail to unknown email');
eq(run("api_requestLogin('bad').ok"), false, 'invalid email rejected');
const st = login(' S1@live.rmutl.ac.th ');
eq(run(`api_exchange('${st.t}').ok`), false, 'login link single use');
eq(run(`api_me('${st.s}').me.role`), 'student', 'me = student');
eq(run(`api_me('x'.repeat(64)).auth`), true, 'bad session -> auth error');
const ad = login('a1@rmutl.ac.th');
const te = login('t1@rmutl.ac.th');

/* ---------- 5. placement ---------- */
console.log('5. Placement');
let r = run(`api_placementGet('${st.s}')`);
ok(r.ok && r.placement === null && r.editable, 'empty placement editable');
const data = {
  company_name: '=HYPERLINK("http://x")', company_type: 'เอกชน', company_address: '99 ถ.ห้วยแก้ว', province: 'เชียงใหม่',
  same_as_301: 'yes', supervisor_name: 'คุณผู้นิเทศ', supervisor_position: 'Tech Lead', supervisor_email: 'Sup@Company.co.th', supervisor_phone: '081-234-5678',
  coadvisor_same: 'yes', position_title: 'Junior Developer', job_description: 'พัฒนา API และแก้บั๊ก',
  problem1_title: 'ระบบติดตามงานซ่อม', problem1_detail: 'ลดเวลาติดตามงานซ่อมด้วยเว็บแอป', work_mode: 'hybrid',
  schedule_305: 'จ–ศ 08:00–12:00', schedule_304: 'พฤ–ศ 14:00–17:00', ip_owner: 'company', compensation: 'ไม่มี', pdpa_consent: true
};
r = run(`api_placementSave('${st.s}', {company_name:'บริษัท ก'}, false)`);
ok(r.ok, 'save partial draft');
r = run(`api_placementSave('${st.s}', {company_name:'บริษัท ก'}, true)`);
ok(!r.ok && r.errors.length > 5, 'submit with missing fields rejected');
r = run(`api_placementSave('${st.s}', ${JSON.stringify(data)}, true)`);
ok(r.ok && r.status === 'submitted', 'submit full placement');
let p = run("placementOf_('s1@live.rmutl.ac.th')");
eq(p.company_name, data.company_name, 'formula-like text stored as text');
eq(p.supervisor_phone, '081-234-5678', 'phone stored as text');
eq(p.supervisor_email, 'sup@company.co.th', 'supervisor email normalized');
ok(!!p.pdpa_consent_at, 'consent timestamp');
eq(run(`api_placementSave('${st.s}', ${JSON.stringify(data)}, false).ok`), false, 'submitted placement locked');
eq(run(`api_adminApprove('${te.s}', '${p.placement_id}', '').error`), 'ไม่มีสิทธิ์ใช้งานส่วนนี้', 'teacher cannot approve');
r = run(`api_adminOverview('${te.s}')`);
ok(r.ok && r.counts.submitted === 1, 'overview counts submitted');
eq(run(`api_adminReturn('${ad.s}', '${p.placement_id}', 'สั้น').ok`), false, 'return needs reason');
r = run(`api_adminReturn('${ad.s}', '${p.placement_id}', 'กรุณาแก้ชื่อบริษัทให้ถูกต้อง')`);
ok(r.ok, 'return ok');
ok(/ส่งกลับ/.test(lastMailTo('s1@live.rmutl.ac.th').subject), 'student notified of return');
r = run(`api_placementSave('${st.s}', ${JSON.stringify(Object.assign({}, data, { company_name: 'บริษัท ซอฟต์แวร์ล้านนา จำกัด' }))}, true)`);
ok(r.ok, 'resubmit after return');
p = run("placementOf_('s1@live.rmutl.ac.th')");
eq(run(`api_logSave('${st.s}', {date:'${today}',start:'08:00',end:'12:00',break_min:0,course:'305',work_mode:'onsite',activity:'ทดสอบก่อนอนุมัติ'}).ok`), false, 'logbook closed before approval');
const mailsBefore = outbox.length;
r = run(`api_adminApprove('${ad.s}', '${p.placement_id}', 'ผ่าน')`);
ok(r.ok && /^SE-WIL01\/2569-001$/.test(r.agreement_no), 'approve -> agreement no ' + r.agreement_no);
eq(outbox.length - mailsBefore, 2, 'two agreement emails (supervisor + student)');
const svMail = lastMailTo('sup@company.co.th');
ok(svMail && svMail.attachments && svMail.attachments.length === 1, 'supervisor mail has PDF attachment');
ok(/16 พฤศจิกายน 2569/.test(svMail.htmlBody), 'supervisor mail states agreement due date');
ok(svMail.htmlBody.indexOf('https://se-rmutl.github.io/se-wil/company/supervisor.html') >= 0, 'supervisor mail links to supervisor guide');
ok(svMail.htmlBody.indexOf('se-rmutl.github.io/se-wil') >= 0 && /คู่มือ ปฏิทิน/.test(svMail.htmlBody), 'mail footer links to portal');
const k = tokenFrom(svMail, 'k');
ok(!!k, 'supervisor link token');
p = run("placementOf_('s1@live.rmutl.ac.th')");
eq(p.status, 'agreement_sent', 'status agreement_sent');

/* ---------- 6. logbook ---------- */
console.log('6. Logbook');
const d1 = dayBefore(3), d2 = dayBefore(2);
const save = (o) => run(`api_logSave('${st.s}', ${JSON.stringify(o)})`);
r = save({ date: d1, start: '08:00', end: '12:00', break_min: 0, course: '305', work_mode: 'onsite', activity: 'พัฒนา REST API สำหรับลูกค้า' });
ok(r.ok && r.hours === 4, 'entry 305 saved 4h');
const e1 = r.entry_id;
r = save({ date: d1, start: '11:00', end: '13:00', break_min: 0, course: '304', work_mode: 'onsite', activity: 'เก็บความต้องการโครงงาน' });
ok(!r.ok && /ซ้อน/.test(r.error), 'overlap rejected');
r = save({ date: d1, start: '14:00', end: '17:00', break_min: 0, course: '304', work_mode: 'remote', activity: 'เก็บความต้องการโครงงานกับผู้ใช้' });
ok(r.ok && r.hours === 3, 'entry 304 saved 3h');
const e2 = r.entry_id;
r = save({ date: d2, start: '08:00', end: '12:00', break_min: 0, course: '305', work_mode: 'onsite', activity: 'สั้น' });
ok(!r.ok, 'short activity rejected');
r = save({ date: dayBefore(-1), start: '08:00', end: '12:00', break_min: 0, course: '305', work_mode: 'onsite', activity: 'บันทึกล่วงหน้าไม่ได้' });
ok(!r.ok && /ล่วงหน้า/.test(r.error), 'future date rejected');
r = save({ date: dayBefore(20), start: '08:00', end: '12:00', break_min: 0, course: '305', work_mode: 'onsite', activity: 'ก่อนเปิดภาคไม่ได้' });
ok(!r.ok && /ก่อนวันเปิดภาค/.test(r.error), 'before semester rejected');
r = save({ date: d2, start: '08:00', end: '12:00', break_min: 0, course: '999', work_mode: 'onsite', activity: 'รหัสวิชาผิดต้องไม่ผ่าน' });
ok(!r.ok, 'bad course rejected');
r = run(`api_logList('${st.s}')`);
ok(r.ok && r.entries.length === 2, 'two entries listed');
const stored = r.entries.filter(e => e.entry_id === e1)[0];
eq(stored.date, d1, 'date read back as text');
eq(stored.start, '08:00', 'time read back as text');
eq(stored.course, '305', 'course read back as text');
eq(r.summary.draft['305'], 4, 'draft 305 = 4');

r = run(`api_logSendNow('${st.s}')`);
ok(r.ok, 'send now creates batch');
const batchId = r.batch_id;
ok(/รอรับรอง/.test(lastMailTo('sup@company.co.th').subject), 'digest mail to supervisor');
eq(run(`api_logSendNow('${st.s}').ok`), false, 'send now rate-limited');
eq(run(`api_logSave('${st.s}', {entry_id:'${e1}',date:'${d1}',start:'08:00',end:'11:00',break_min:0,course:'305',work_mode:'onsite',activity:'แก้ไขรายการที่ส่งแล้ว'}).ok`), false, 'pending entry locked');
eq(run(`api_logDelete('${st.s}', '${e1}').ok`), false, 'pending entry cannot be deleted');

/* ---------- 7. supervisor ---------- */
console.log('7. Supervisor');
eq(run(`api_svGet('${'x'.repeat(64)}').ok`), false, 'bad supervisor token rejected');
r = run(`api_svGet('${k}')`);
ok(r.ok && r.agreements.length === 1 && r.pending.length === 1 && r.pending[0].entries.length === 2, 'supervisor sees agreement and batch');
eq(run(`api_svAcceptAgreement('${k}', '${p.placement_id}', 'คุณผู้นิเทศ', false).ok`), false, 'accept requires checkbox');
r = run(`api_svAcceptAgreement('${k}', '${p.placement_id}', 'คุณผู้นิเทศ ใจดี', true)`);
ok(r.ok, 'accept agreement online');
eq(run("placementOf_('s1@live.rmutl.ac.th').status"), 'signed', 'placement signed');
eq(run(`api_svDecide('${k}', '${batchId}', ['${e1}'], [], '').ok`), false, 'decision must cover all entries');
eq(run(`api_svDecide('${k}', '${batchId}', ['${e1}'], ['${e2}'], '').ok`), false, 'return needs reason');
r = run(`api_svDecide('${k}', '${batchId}', ['${e1}'], ['${e2}'], 'กรุณาระบุรายละเอียดผู้ใช้ที่สัมภาษณ์')`);
ok(r.ok && r.status === 'partial', 'partial certification');
ok(/ส่งกลับ/.test(lastMailTo('s1@live.rmutl.ac.th').subject), 'student notified of returned entries');
eq(run(`api_svDecide('${k}', '${batchId}', ['${e1}'], ['${e2}'], 'ซ้ำ').ok`), false, 'batch cannot be decided twice');
r = run(`api_logList('${st.s}')`);
eq(r.summary.certified['305'], 4, 'certified 305 = 4');
eq(r.summary.returned['304'], 3, 'returned 304 = 3');
r = save({ entry_id: e2, date: d1, start: '14:00', end: '17:30', break_min: 0, course: '304', work_mode: 'remote', activity: 'สัมภาษณ์ผู้ใช้ 3 คน ฝ่ายซ่อมบำรุง' });
ok(r.ok && r.hours === 3.5, 'returned entry edited -> draft');
eq(run(`api_logDelete('${st.s}', '${e1}').ok`), false, 'certified entry cannot be deleted');

/* ---------- 8. weekly digest ---------- */
console.log('8. Digest');
props.LAST_DIGEST_AT = new Date(Date.now() - 3600e3).toISOString();
r = run('job_weeklyDigest()');
ok(r.batches === 1 && r.emails === 1, 'digest created 1 batch and 1 email');
ok(run('job_weeklyDigest()').skipped, 'digest rate-limited');
eq(run(`api_adminRunDigest('${te.s}').ok`), false, 'teacher cannot run digest');
r = run(`api_adminStudent('${te.s}', 's1@live.rmutl.ac.th')`);
ok(r.ok && r.entries.length === 2 && r.batches.length === 2, 'teacher sees student detail');
r = run(`api_adminOverview('${ad.s}')`);
eq(r.counts.signed, 1, 'overview counts signed');
// fixtures for UI preview
fs.writeFileSync(path.join(__dirname, 'fixtures.json'), JSON.stringify({
  me: run(`api_me('${st.s}')`), placementGet: run(`api_placementGet('${st.s}')`), logList: run(`api_logList('${st.s}')`),
  adminMe: run(`api_me('${ad.s}')`), adminOverview: run(`api_adminOverview('${ad.s}')`), adminStudent: run(`api_adminStudent('${ad.s}', 's1@live.rmutl.ac.th')`),
  svGet: run(`api_svGet('${k}')`)
}, null, 1));
r = run(`api_logout('${st.s}')`);
eq(run(`api_me('${st.s}').ok`), false, 'logout invalidates session');

console.log('8b. Link rotation');
run(`(function(){ var r=findOne_('Supervisors',function(x){return x.email==='sup@company.co.th';}); update_('Supervisors', r._row, {token:''}); })()`);
eq(run(`api_svGet('${k}').ok`), false, 'revoked supervisor link rejected');
const k2 = run(`getOrCreateSupervisor_('sup@company.co.th','').token`);
ok(k2 && k2.length >= 32 && k2 !== k, 'new supervisor token issued');
eq(run(`api_svGet('${k2}').ok`), true, 'new link works');

/* ---------- 9. audit and sheet hygiene ---------- */
console.log('9. Hygiene');
const anyDateObjects = Object.values(book.sheets).filter(s => ['Logbook', 'Placements', 'CertBatches'].indexOf(s.name) >= 0)
  .some(s => s.data.slice(1).some(row => row.some(v => v instanceof Date)));
ok(!anyDateObjects, 'no auto-converted Date cells in data sheets');
const anyFormula = Object.values(book.sheets).some(s => s.data.some(row => row.some(v => v === '#FORMULA!')));
ok(!anyFormula, 'no formula injection');
ok(book.sheets.Audit.data.length > 10, 'audit trail written');

/* ---------- 10. portal consistency ---------- */
console.log('10. Portal consistency');
eq(run("thDateLong_('2026-11-13')"), '13 พฤศจิกายน 2569', 'Thai long date');
eq(run("thDateLong_('')"), '', 'Thai long date blank');
eq(run("portalUrl_('help/index.html')"), 'https://se-rmutl.github.io/se-wil/help/index.html', 'portal url join');
eq(run("cfg_().PLACEMENT_DUE"), '2026-11-13', 'placement due matches portal');
eq(run("cfg_().AGREEMENT_DUE"), '2026-11-16', 'agreement due matches portal');
eq(run("cfg_().DIGEST_DAY + ' ' + cfg_().DIGEST_HOUR"), 'FRIDAY 15', 'digest Friday 15:00 as on portal');
eq(run("cfg_().TARGET_305 + '/' + cfg_().TARGET_304 + '/' + cfg_().MAX_HOURS_PER_DAY + '/' + cfg_().LOGIN_LINK_MINUTES"), '300/135/12/30', 'targets and limits match portal');
eq(run("(function(){var d={};CONFIG_DEFAULTS.forEach(function(r){d[r[0]]=r[1];});return d.SEMESTER_START+'..'+d.SEMESTER_END;})()"), '2026-11-18..2027-03-09', 'default term dates match portal');

console.log(`\n${pass} passed, ${failN} failed`);
process.exit(failN ? 1 : 0);
