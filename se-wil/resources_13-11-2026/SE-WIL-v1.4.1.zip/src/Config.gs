/**
 * Config.gs — ค่าคงที่ โครงสร้างชีต และการอ่านค่าตั้งค่า
 * ระบบ SE-WIL (ENGSE304/ENGSE305) หลักสูตรวิศวกรรมซอฟต์แวร์ มทร.ล้านนา
 */

var TZ = 'Asia/Bangkok';

/** โครงสร้างแต่ละชีต (แถวที่ 1 คือหัวคอลัมน์) */
var SCHEMA = {
  Config: ['key', 'value', 'note'],
  Users: ['email', 'role', 'student_id', 'name', 'phone', 'section', 'advisor_email', 'active'],
  Placements: [
    'placement_id', 'student_email', 'student_id', 'student_name', 'student_phone', 'status', 'agreement_no',
    'company_name', 'company_type', 'company_address', 'province', 'company_phone', 'company_website', 'company_map_url',
    'company_photo_id', 'cv_file_id', 'cv_file_name', 'cv_uploaded_at', 'same_as_301', 'change_reason',
    'supervisor_name', 'supervisor_position', 'supervisor_email', 'supervisor_phone',
    'coadvisor_same', 'coadvisor_name', 'coadvisor_position', 'coadvisor_email', 'coadvisor_phone',
    'position_title', 'job_description', 'problem1_title', 'problem1_detail', 'problem2_title', 'problem2_detail',
    'work_mode', 'schedule_305', 'schedule_304', 'ip_owner', 'compensation', 'pdpa_consent_at',
    'submitted_at', 'reviewed_by', 'reviewed_at', 'review_comment',
    'agreement_doc_id', 'agreement_pdf_id', 'agreement_pdf_url', 'agreement_generated_at',
    'accepted_by_name', 'accepted_at', 'accepted_via', 'created_at', 'updated_at'
  ],
  Supervisors: ['email', 'name', 'token', 'created_at', 'last_access_at'],
  Logbook: [
    'entry_id', 'placement_id', 'student_email', 'date', 'start', 'end', 'break_min', 'hours',
    'course', 'work_mode', 'activity', 'status', 'batch_id', 'return_comment', 'created_at', 'updated_at'
  ],
  CertBatches: [
    'batch_id', 'placement_id', 'student_email', 'supervisor_email', 'created_at', 'entry_ids',
    'hours_305', 'hours_304', 'status', 'decided_at', 'decided_by_name', 'comment'
  ],
  Sessions: ['token_hash', 'email', 'kind', 'expires_at', 'used', 'created_at'],
  Audit: ['ts', 'actor', 'action', 'target', 'detail']
};

/** ค่าเริ่มต้นของชีต Config: [key, value, note] */
var CONFIG_DEFAULTS = [
  ['PROGRAM_NAME', 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมซอฟต์แวร์ คณะวิศวกรรมศาสตร์ มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา', 'ชื่อเต็มในเอกสาร'],
  ['PROGRAM_SHORT', 'หลักสูตรวิศวกรรมซอฟต์แวร์ มทร.ล้านนา', 'ชื่อย่อในอีเมล'],
  ['PROGRAM_EMAIL', '', 'อีเมลสำหรับตอบกลับ (reply-to) ปกติใช้อีเมลผู้ประสานงาน SE-WIL เว้นว่างได้ ระบบจะใช้ COORDINATOR_EMAIL'],
  ['COORDINATOR_NAME', 'อาจารย์ธนิต เกตุแก้ว', 'ผู้ประสานงาน SE-WIL ผู้ติดต่อหลักของนักศึกษาและสถานประกอบการ แสดงเป็นรายชื่อแรกในระบบ อีเมล และข้อตกลง'],
  ['COORDINATOR_EMAIL', 'thanit@rmutl.ac.th', 'อีเมลผู้ประสานงาน SE-WIL (อีเมลงาน)'],
  ['COORDINATOR_PHONE', '', 'ไม่บังคับ ใส่เฉพาะเบอร์ที่เจ้าตัวยินยอม แสดงเฉพาะผู้เกี่ยวข้องกับการฝึกแต่ละราย (ในระบบ อีเมลถึงผู้นิเทศงาน และข้อตกลง) ไม่แสดงในพอร์ทัลสาธารณะ'],
  ['PROGRAM_HEAD_NAME', '', 'ชื่อหัวหน้าหลักสูตร แสดงในระบบเป็นผู้ติดต่อกรณีจำเป็น และในข้อตกลง (ชื่อและอีเมล)'],
  ['PROGRAM_HEAD_EMAIL', '', 'อีเมลหัวหน้าหลักสูตร'],
  ['PROGRAM_HEAD_PHONE', '', 'ไม่บังคับ ใส่เฉพาะเบอร์ที่เจ้าตัวยินยอม แสดงเฉพาะในระบบแก่ผู้เกี่ยวข้อง ไม่แสดงในข้อตกลง อีเมล หรือพอร์ทัล'],
  ['SEMESTER_LABEL', '2/2569', ''],
  ['SEMESTER_START', '2026-11-18', 'วันเปิดภาค รูปแบบ ค.ศ. yyyy-MM-dd'],
  ['SEMESTER_END', '2027-03-09', 'วันสุดท้ายที่บันทึกชั่วโมงได้'],
  ['PERIOD_TEXT', '18 พฤศจิกายน 2569 ถึง 9 มีนาคม 2570', 'ข้อความช่วงเวลาฝึกในข้อตกลง'],
  ['TARGET_305', '300', 'ชั่วโมงขั้นต่ำ ENGSE305'],
  ['TARGET_304', '135', 'ชั่วโมงขั้นต่ำ ENGSE304'],
  ['WEEKLY_305', '20', 'ชั่วโมงต่อสัปดาห์ที่คาดหวัง ENGSE305'],
  ['WEEKLY_304', '9', 'ชั่วโมงต่อสัปดาห์ที่คาดหวัง ENGSE304 (6 ณ สถานประกอบการ + 3 ศึกษาเอง)'],
  ['DIGEST_DAY', 'FRIDAY', 'วันที่ส่งสรุปให้ผู้นิเทศงาน (MONDAY–SUNDAY)'],
  ['DIGEST_HOUR', '15', 'ชั่วโมงที่ส่งสรุป (0–23)'],
  ['SESSION_DAYS', '14', 'อายุการเข้าระบบ (วัน)'],
  ['LOGIN_LINK_MINUTES', '30', 'อายุลิงก์เข้าระบบในอีเมล (นาที)'],
  ['MAX_HOURS_PER_DAY', '12', 'ชั่วโมงสูงสุดต่อวัน'],
  ['CV_REQUIRED', 'FALSE', 'TRUE = ต้องแนบ CV ก่อนส่งข้อมูลที่ฝึก'],
  ['MAX_UPLOAD_MB', '5', 'ขนาดไฟล์สูงสุดที่แนบได้ (CV และรูปสถานประกอบการ)'],
  ['APP_URL', '', 'URL ของเว็บแอปที่ลงท้ายด้วย /exec ใส่หลัง Deploy'],
  ['PORTAL_URL', 'https://se-rmutl.github.io/se-wil/', 'พอร์ทัลรายวิชา ใช้เป็นลิงก์คู่มือในหน้าเว็บแอปและในอีเมล'],
  ['PLACEMENT_DUE', '2026-11-13', 'วันสุดท้ายที่นักศึกษาส่งข้อมูลที่ฝึก (ต้องตรงกับพอร์ทัล)'],
  ['AGREEMENT_DUE', '2026-11-16', 'วันสุดท้ายที่สถานประกอบการยืนยันข้อตกลง SE-WIL01 (ต้องตรงกับพอร์ทัล)'],
  ['ROOT_FOLDER_ID', '', 'โฟลเดอร์ Google Drive ของรายวิชา เว้นว่างได้ setup() จะใช้โฟลเดอร์ที่เก็บชีตนี้'],
  ['TEMPLATE_DOC_ID', '', 'สร้างอัตโนมัติโดย setup()'],
  ['OUTPUT_FOLDER_ID', '', 'สร้างอัตโนมัติโดย setup()']
];

/** สถานะที่นักศึกษาบันทึก logbook ได้ */
var LOGBOOK_OPEN_STATUSES = ['agreement_sent', 'signed'];

var COMPANY_TYPES = ['เอกชน', 'รัฐวิสาหกิจ', 'หน่วยงานราชการ', 'ชุมชนหรือองค์กรไม่แสวงหากำไร'];
var WORK_MODES = { onsite: 'ปฏิบัติงาน ณ สถานประกอบการ', hybrid: 'แบบผสม (ณ สถานประกอบการและทางไกล)', remote: 'ทางไกลทั้งหมด' };
var IP_OWNERS = {
  company: 'สถานประกอบการเป็นเจ้าของผลงาน',
  joint: 'สถานประกอบการและนักศึกษา/มหาวิทยาลัยเป็นเจ้าของร่วมกัน',
  student: 'นักศึกษาและมหาวิทยาลัยเป็นเจ้าของผลงาน'
};

var _configCache = null;

/** อ่านค่าตั้งค่าทั้งหมดเป็น object (แคชต่อการเรียกหนึ่งครั้ง) */
function cfg_() {
  if (_configCache) return _configCache;
  var out = {};
  CONFIG_DEFAULTS.forEach(function (r) { out[r[0]] = r[1]; });
  try {
    readAll_('Config').forEach(function (r) {
      if (r.key) out[String(r.key).trim()] = String(r.value === undefined ? '' : r.value).trim();
    });
  } catch (e) { /* ยังไม่ได้ setup */ }
  _configCache = out;
  return out;
}

function cfgNum_(key) {
  var v = Number(cfg_()[key]);
  return isNaN(v) ? 0 : v;
}

function resetConfigCache_() { _configCache = null; }

var TH_MONTHS_ = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];

/** '2026-11-13' -> '13 พฤศจิกายน 2569' (ค่าว่างหรือรูปแบบอื่นคืนค่าเดิม) */
function thDateLong_(iso) {
  var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || '').trim());
  if (!m) return String(iso || '');
  return Number(m[3]) + ' ' + TH_MONTHS_[Number(m[2]) - 1] + ' ' + (Number(m[1]) + 543);
}

/** URL ของพอร์ทัลรายวิชา ต่อท้ายด้วย path ได้ เช่น portalUrl_('company/supervisor.html') */
function portalUrl_(path) {
  var base = String(cfg_().PORTAL_URL || '').trim();
  if (!base) return '';
  if (base.slice(-1) !== '/') base += '/';
  return base + (path || '');
}

/** URL ของเว็บแอป */
function appUrl_() {
  var u = cfg_().APP_URL;
  if (u) return u;
  try { return ScriptApp.getService().getUrl(); } catch (e) { return ''; }
}
